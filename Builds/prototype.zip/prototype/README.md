# Prism Break

This is the Unity version of our Gameplay Prototype. 

There is an .exe executable and a WebGL build in this folder (Unity doesn't built .jar). 
The WebGL build is also playable at https://boonp.itch.io/prism-break?password=prism.

To move the character, use the left and right arrow keys.
Use the up arrow to jump.
Press R to restart a level.

There are 4 levels. When level 4 is beaten it takes you back to level 1.
